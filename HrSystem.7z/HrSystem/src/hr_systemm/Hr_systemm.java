/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr_systemm;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Hr_systemm  extends JFrame implements MouseListener{
    String y[]={"yyyy", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1986", "1985", "1984", "1983", "1982", "1981", "1979", "1978", "1977", "1976", "1975", "1975", "1974", "1973", "1972" };
     String d[]={ "dd", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
    String m[]={ "mm", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
    
    JPanel singin =new JPanel();
JPanel jPanel1 =new JPanel();
JPanel side_pane =new JPanel();
JLabel   jLabel1 =new JLabel();
JLabel   well =new JLabel();
JLabel   jLabel =new JLabel();
JLabel   day =new JLabel();
JPanel btn_2 =new JPanel();
JLabel   jLabel2 =new JLabel();
JPanel panel3=new JPanel();
JPanel  btn_1=new JPanel();
JPanel  btn_3=new JPanel();
JLabel   jLabel3 =new JLabel();
JPanel  btn_4=new JPanel( );
JPanel  btn_5=new JPanel( );
JLabel   jLabel4 =new JLabel();
JLabel   jLabel5 =new JLabel();
JLabel   image =new JLabel();
JLabel   newem =new JLabel();
JTextField user=new JTextField();
JTextField lastname=new JTextField();
JTextField firstname=new JTextField();
JTextField place=new JTextField();
JTextField email=new JTextField();
JPasswordField jTextField4=new JPasswordField();
JPanel employs=new JPanel();
JPanel NewEmploys=new JPanel();
JTextField search=new JTextField(15);
JPanel line=new JPanel();
JRadioButton jRadioButton1=new JRadioButton();
    JComboBox yyyy=new JComboBox(y);
    JComboBox dd=new JComboBox(d);
    JComboBox mm=new JComboBox(m);
JRadioButton jRadioButton2=new JRadioButton();
      ButtonGroup bg=new ButtonGroup();
              

        
JButton jButton3=new JButton(
new AbstractAction() {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }


);
JButton search1=new JButton(
new AbstractAction() {
        @Override
        public void actionPerformed(ActionEvent e) {
            
        }
    }


);
JButton upload=new JButton(
new AbstractAction() {
        @Override
        public void actionPerformed(ActionEvent e) {
           JFileChooser jfc = new JFileChooser();
jfc.addChoosableFileFilter(new FileNameExtensionFilter("Images", "jpg", "png", "gif", "bmp"));
		

int returnValue = jfc.showOpenDialog(null);
if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = jfc.getSelectedFile();
			System.out.println(selectedFile.getAbsolutePath());
                        image.setIcon(new javax.swing.ImageIcon(selectedFile.getAbsolutePath()));
		}
        }
    }


);
JButton sumbit=new JButton(
new AbstractAction() {
        @Override
        public void actionPerformed(ActionEvent e) {
          
        }
    }


);
JButton jButton2=new JButton(
new AbstractAction() {
        @Override
        public void actionPerformed(ActionEvent e) {
           jPanel1.show();
           singin.hide();
           setBounds(0, 0, 1040, 560);
               setLocationRelativeTo(null);
               employs.show();
                  btn_1.setBackground(new java.awt.Color(29, 46, 69));
        }
    }


);
  public Hr_systemm(){
      setUndecorated(true);
    
      jPanel1.setBackground((Color.WHITE));
        jPanel1.setLayout(null);
        getContentPane().add(jPanel1);
                jPanel1.setBounds(0, 0, 1040, 560);
      jPanel1.setBackground((Color.WHITE));
        jPanel1.setLayout(null);
        getContentPane().add(jPanel1);
                jPanel1.setBounds(0, 0, 1040, 560);
      //..  setBounds(0, 0, 1040, 560);
         user.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        user.setText("username");
        singin.add(user);
      user.setBounds(260, 150, 210, 40);
      user.addMouseListener(this);
     singin.setBackground((Color.WHITE));
       singin.setLayout(null);
        getContentPane().add(singin);
                singin.setBounds(0, 0, 760, 430);
                jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButton3.setText("close ");
        jButton3.setForeground(Color.WHITE);
        singin.add(jButton3);
        singin.add(well);
        jButton3.setBounds(610, 380, 90, 30);
   setBounds(0, 0, 760, 430);
         well.setFont(new java.awt.Font("Dialog", 0, 48)); // NOI18welll
       well.setForeground(new java.awt.Color(0, 0, 0));
        well.setText("Wellcome");
      
        well.setBounds(260, 20, 270, 50);
 jTextField4.addMouseListener(this);
        jTextField4.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField4.setText("xxxxxxxx");
       singin.add(jTextField4);
        jTextField4.setBounds(260, 220, 210, 40);
  jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jButton2.setText("Login");
        singin.add(jButton2);
        jButton2.setBounds(300, 300, 120, 40);
        jButton2.setForeground(Color.WHITE);
        jPanel1.hide();
        //employ ......................
        jPanel1.add(side_pane);
      side_pane.setBounds(0, 0, 120, 600);
       side_pane.setBackground(new java.awt.Color(23, 35, 51));
       side_pane.setLayout(null);
               side_pane.add(btn_1);
        btn_1.setBackground(new java.awt.Color(23, 35, 51));
     
        btn_1.setBounds(0, 100, 120, 40);
        jPanel1.add(employs);
        employs.setBounds(120, 0, 950, 600);
        employs.setBackground(Color.WHITE);
        employs.hide();
        
         jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Employs");
        btn_1.add(jLabel1);
        jLabel1.setBounds(38, 12, 33, 26);
          btn_1.addMouseListener(this);
          search.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        search.setText("Search");
        search.addMouseListener(this);
        employs.add(search);
        employs.setLayout(null);
        search.setBounds(340, 40, 210, 40);
           search1.setText("search");
        employs.add(search1);
      search1.setBounds(570, 45, 80, 30);
      search1.setBackground(Color.BLACK);
      search1.setForeground(Color.WHITE);

          line .setBackground(Color.BLACK);
        employs.add(line);
        line.setBounds(0, 130, 1020, 2);
          
     
          
          
          
          
          
     //......................................................
        //new employ..................................
        side_pane.add(btn_2);
        btn_2.setBounds(0, 150, 120, 40);
          btn_2.setBackground(new java.awt.Color(23, 35, 51));
         jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel2.setForeground(Color.WHITE);
        jLabel2.setText("New Employ");
            jLabel2.setBounds(38, 12, 33, 26);
        btn_2.add(jLabel2);
          btn_2.addMouseListener(this);
               
           jPanel1.add(NewEmploys);
        NewEmploys.setBounds(120, 0, 950, 600);
        NewEmploys.setBackground(Color.WHITE);
        NewEmploys.hide();
        
               newem.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        newem.setText("Rigester new employ");
      NewEmploys.add(newem);
      NewEmploys.setLayout(null);
       newem.setBounds(250, 20, 360, 70);
           email.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
       email.setText("Email");
       NewEmploys.add(email);
        email.setBounds(60, 330, 380, 30);

        firstname.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        firstname.setText("firstname");
     NewEmploys.add(firstname);
      firstname.setBounds(60, 130, 150, 30);

        lastname.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
    lastname.setText("lastname");
        NewEmploys.add(lastname);
        lastname.setBounds(60, 180, 150, 30);

       place.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
   place.setText("place");
     NewEmploys.add(place);
       place.setBounds(60, 280, 150, 30);
    NewEmploys.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jRadioButton1.setText("female");
       jRadioButton1.setBackground(Color.WHITE);
           jRadioButton1.setBounds(140, 220, 100, 30);
           NewEmploys.add(jRadioButton2);
           jRadioButton2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jRadioButton2.setText("male");
          jRadioButton2.setBounds(60, 220, 70, 30);
          jRadioButton2.setBackground(Color.WHITE);
          
          bg.add(jRadioButton1);
          bg.add(jRadioButton2);
         image.setIcon(new javax.swing.ImageIcon("icon\\images.png")); // NOI18N
        NewEmploys.add(image);
        image.setBounds(630, 120, 210, 140);
upload.setIcon(new javax.swing.ImageIcon("icon\\icons8-upload-26.png")); // NOI18N
      
      NewEmploys.add(upload);
       upload.setBounds(710, 290, 60, 36);
          upload.setBackground(Color.WHITE);
          
        sumbit.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
     sumbit.setText("Sumbit");
      NewEmploys.add(sumbit);
        sumbit.setBounds(670, 500, 100, 30);
          sumbit.setBackground(Color.BLACK);
          sumbit.setForeground(Color.WHITE);
         day.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        day.setText("born date:");
        NewEmploys.add(day);
       day.setBounds(70, 390, 110, 20);
         NewEmploys.add(yyyy);
        yyyy.setBounds(360, 390, 100, 24);
yyyy.setBackground(Color.WHITE);
NewEmploys.add(dd);
       dd.setBounds(280, 390, 60, 24);
dd.setBackground(Color.WHITE);
 NewEmploys.add(mm);
        mm.setBounds(200, 390, 50, 24);
mm.setBackground(Color.white);



        // Rigester...........
        
            side_pane.add(btn_3);
        btn_3.setBounds(0, 200, 120, 40);
          btn_3.setBackground(new java.awt.Color(23, 35, 51));
         jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel3.setForeground(Color.WHITE);
        jLabel3.setText("Rigester");
            jLabel3.setBounds(38, 12, 33, 26);
        btn_3.add(jLabel3);
          btn_3.addMouseListener(this);
          //log out...
          
              side_pane.add(btn_5);
        btn_5.setBounds(0, 250, 120, 40);
          btn_5.setBackground(new java.awt.Color(23, 35, 51));
         jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel5.setForeground(Color.WHITE);
        jLabel5.setText("log out");
            jLabel5.setBounds(38, 12, 33, 26);
        btn_5.add(jLabel5);
       btn_5.addMouseListener(this);
        //close.............. 
        
              side_pane.add(btn_4);
        btn_4.setBounds(0, 300, 120, 40);
          btn_4.setBackground(new java.awt.Color(23, 35, 51));
         jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel4.setForeground(Color.WHITE);
        jLabel4.setText("close");
            jLabel4.setBounds(38, 12, 33, 26);
        btn_4.add(jLabel4);
       btn_4.addMouseListener(this);
      
        
        
        
          setLocationRelativeTo(null);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    }
    
    
    
    
    
    public static void main(String[] args) {
    Hr_systemm obj=new Hr_systemm();
    obj.show();
    obj.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }


    public void mouseClicked(MouseEvent e) {
        if (e.getSource()==btn_5) {
         jPanel1.hide();
         singin.show();
               setBounds(0, 0, 760, 430);
               setLocationRelativeTo(null);
               user.setText("username");
                jTextField4.setText("xxxxxxxx");
        }
        if (e.getSource()==btn_4) {
            dispose();
            
        }
        if (e.getSource()==btn_2) {
          NewEmploys.show();
            employs.hide();
            
              btn_1.setBackground(new java.awt.Color(23, 35, 51));
        }

        if (e.getSource()==btn_1) {
         employs.show();
         search.setText("Search");
        }
         if (e.getSource()==jTextField4) {
         jTextField4.setText("");
            
        }
         if (e.getSource()==user) {
         user.setText("");
            
        }
         if (e.getSource()==search) {
         search.setText("");
            
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
         if (e.getSource()==btn_4) {
         
            
        }
   
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    
       
        if (e.getSource()==btn_1) {
         
             btn_1.setBackground(new java.awt.Color(29, 46, 69)); 
        }
    
        if (e.getSource()==btn_2) {
         
             btn_2.setBackground(new java.awt.Color(29, 46, 69)); 
        }
    
        if (e.getSource()==btn_3) {
         
             btn_3.setBackground(new java.awt.Color(29, 46, 69)); 
        }
    
        if (e.getSource()==btn_4) {
         
             btn_4.setBackground(new java.awt.Color(29, 46, 69)); 
        }
        if (e.getSource()==btn_5) {
         
             btn_5.setBackground(new java.awt.Color(29, 46, 69)); 
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
         if (e.getSource()==btn_1) {
          
              btn_1.setBackground(new java.awt.Color(23, 35, 51));
        }
         if (e.getSource()==btn_2) {
          
              btn_2.setBackground(new java.awt.Color(23, 35, 51));
              
        }
         if (e.getSource()==btn_3) {
          
              btn_3.setBackground(new java.awt.Color(23, 35, 51));
        }
         if (e.getSource()==btn_4) {
          
              btn_4.setBackground(new java.awt.Color(23, 35, 51));
        }
         if (e.getSource()==btn_5) {
          
              btn_5.setBackground(new java.awt.Color(23, 35, 51));
        }
         if (e.getSource()==jTextField4) {
          
              jTextField4.setText(jTextField4.getText());
        }
         if (e.getSource()==user) {
          
              user.setText(user.getText());
        }
         if (e.getSource()==search) {
          
              search.setText(search.getText());
        }
    }
    
}
